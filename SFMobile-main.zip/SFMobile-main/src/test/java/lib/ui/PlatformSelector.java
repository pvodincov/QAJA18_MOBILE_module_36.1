package lib.ui;

public class PlatformSelector {
    public final static String PLATFORM = "ios";
}
