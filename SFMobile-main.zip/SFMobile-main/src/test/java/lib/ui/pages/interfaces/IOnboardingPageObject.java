package lib.ui.pages.interfaces;

public interface IOnboardingPageObject {
    public void skipOnboarding();
}
