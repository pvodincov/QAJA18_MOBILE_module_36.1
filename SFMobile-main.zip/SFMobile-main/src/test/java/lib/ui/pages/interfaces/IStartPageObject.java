package lib.ui.pages.interfaces;

public interface IStartPageObject {
    public void initSearch();
}
