package lib.ui.pages.interfaces;

public interface ISearchPageObject {
    public void findByText(String text);
    public void selectByText(String text);
}
